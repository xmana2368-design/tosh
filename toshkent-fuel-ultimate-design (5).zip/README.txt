TOSHKENT FUEL — RESPONSIVE ONLINE + OFFLINE PWA

DIZAYN:
- Desktop (820px va undan keng): ikki ustunli dashboard, marshrut paneli chapda.
- Telefon va planshet: bir ustunli, moslashuvchan mobil interfeys.
- Kengaytirilgan kartalar, tugmalar, fokus holatlari va kamaytirilgan animatsiya sozlamasi.
- PWA cache versiyasi yangilandi; yangi dizayn eski shell cache bilan to‘qnashmaydi.

1) Shu papkadagi fayllarni HTTPS hostingga joylashtiring (Netlify yoki GitHub Pages).
2) Saytni Chrome orqali oching va "Ilovani o‘rnatish" / "Add to Home screen" ni tanlang.
3) Internet bor paytda A va B nuqtalarini kiriting va qidiruvni bir marta bajaring.
4) Oxirgi muvaffaqiyatli marshrut, yoqilg‘i ma’lumotlari va zapravka natijalari qurilmada saqlanadi.
5) Internet uzilganda shu oxirgi saqlangan A–B marshrutini qayta ochib, GPS kuzatuvidan foydalanish mumkin.

CHEGARALAR:
- Offline rejimda yangi manzil qidirish, yangi marshrut hisoblash va jonli zapravka yangilanishi ishlamaydi.
- Bu versiya yo‘l geometriyasi va zapravka nuqtalarini saqlaydi; uchinchi tomon xarita plitkalari ommaviy yuklab olinmaydi.
- Ko‘cha nomlari bilan to‘liq offline xarita uchun litsenziyasi offline yuklashga ruxsat beradigan alohida xarita provayderi yoki o‘z tile server kerak.
- Offline navigatsiya saqlangan marshrut chizig‘i + GPS kuzatuviga asoslanadi; internet bo‘lmasa avtomatik qayta marshrutlash yo‘q.
- PWA service worker faqat HTTPS yoki localhost muhitida ishlaydi; content:// va file:// dan emas.
